-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: test100
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications_application`
--

DROP TABLE IF EXISTS `applications_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applications_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `package` varchar(255) NOT NULL,
  `version_name` varchar(255) NOT NULL,
  `version_code` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `md5` varchar(32) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `applications_applica_organization_id_454e8aa4_fk_authentic` (`organization_id`),
  CONSTRAINT `applications_applica_organization_id_454e8aa4_fk_authentic` FOREIGN KEY (`organization_id`) REFERENCES `authentication_organization` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications_application`
--

LOCK TABLES `applications_application` WRITE;
/*!40000 ALTER TABLE `applications_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `applications_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_trails_auditrecord`
--

DROP TABLE IF EXISTS `audit_trails_auditrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_trails_auditrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime(6) NOT NULL,
  `ip_address` char(39) NOT NULL,
  `model` varchar(255) NOT NULL,
  `operation` varchar(20) NOT NULL,
  `old_data` longtext NOT NULL,
  `new_data` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_trails_auditrecord_user_id_697f0973_fk_auth_user_id` (`user_id`),
  CONSTRAINT `audit_trails_auditrecord_user_id_697f0973_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_trails_auditrecord`
--

LOCK TABLES `audit_trails_auditrecord` WRITE;
/*!40000 ALTER TABLE `audit_trails_auditrecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_trails_auditrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_group_organization_id_bcdb2d26_fk_authentic` (`organization_id`),
  CONSTRAINT `auth_group_organization_id_bcdb2d26_fk_authentic` FOREIGN KEY (`organization_id`) REFERENCES `authentication_organization` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `email` varchar(254) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `sip_server_id` int(11) DEFAULT NULL,
  `preferences` longtext NOT NULL,
  `auto_answer` tinyint(1) NOT NULL,
  `device_default` tinyint(1) NOT NULL,
  `display_mode` varchar(1) NOT NULL,
  `attempts` smallint(6),
  `last_attempt` datetime(6) DEFAULT NULL,
  `type` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `auth_user_organization_id_0289f812_fk_authentic` (`organization_id`),
  KEY `auth_user_sip_server_id_6c0930c1_fk_authentication_sipserver_id` (`sip_server_id`),
  CONSTRAINT `auth_user_organization_id_0289f812_fk_authentic` FOREIGN KEY (`organization_id`) REFERENCES `authentication_organization` (`id`),
  CONSTRAINT `auth_user_sip_server_id_6c0930c1_fk_authentication_sipserver_id` FOREIGN KEY (`sip_server_id`) REFERENCES `authentication_sipserver` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authentication_organization`
--

DROP TABLE IF EXISTS `authentication_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authentication_organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_organization`
--

LOCK TABLES `authentication_organization` WRITE;
/*!40000 ALTER TABLE `authentication_organization` DISABLE KEYS */;
/*!40000 ALTER TABLE `authentication_organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authentication_sipserver`
--

DROP TABLE IF EXISTS `authentication_sipserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authentication_sipserver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `server` varchar(255) NOT NULL,
  `port` int(11) NOT NULL,
  `transport` varchar(1) NOT NULL,
  `srtp_mode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_sipserver`
--

LOCK TABLES `authentication_sipserver` WRITE;
/*!40000 ALTER TABLE `authentication_sipserver` DISABLE KEYS */;
/*!40000 ALTER TABLE `authentication_sipserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authentication_userrelation`
--

DROP TABLE IF EXISTS `authentication_userrelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authentication_userrelation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user1_id` int(11) NOT NULL,
  `user2_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authentication_userrelation_user1_id_user2_id_f20c638c_uniq` (`user1_id`,`user2_id`),
  KEY `authentication_userrelation_user2_id_3300e304_fk_auth_user_id` (`user2_id`),
  CONSTRAINT `authentication_userrelation_user1_id_e3b214e6_fk_auth_user_id` FOREIGN KEY (`user1_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `authentication_userrelation_user2_id_3300e304_fk_auth_user_id` FOREIGN KEY (`user2_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_userrelation`
--

LOCK TABLES `authentication_userrelation` WRITE;
/*!40000 ALTER TABLE `authentication_userrelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `authentication_userrelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authtoken_token`
--

DROP TABLE IF EXISTS `authtoken_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authtoken_token` (
  `key` varchar(40) NOT NULL,
  `created` datetime(6) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `authtoken_token_user_id_35299eff_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authtoken_token`
--

LOCK TABLES `authtoken_token` WRITE;
/*!40000 ALTER TABLE `authtoken_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `authtoken_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-05-17 12:24:23.188548'),(2,'contenttypes','0002_remove_content_type_name','2019-05-17 12:24:24.514541'),(3,'auth','0001_initial','2019-05-17 12:24:30.464569'),(4,'auth','0002_alter_permission_name_max_length','2019-05-17 12:24:30.705692'),(5,'auth','0003_alter_user_email_max_length','2019-05-17 12:24:30.754180'),(6,'auth','0004_alter_user_username_opts','2019-05-17 12:24:30.803899'),(7,'auth','0005_alter_user_last_login_null','2019-05-17 12:24:30.853730'),(8,'auth','0006_require_contenttypes_0002','2019-05-17 12:24:30.906900'),(9,'auth','0007_alter_validators_add_error_messages','2019-05-17 12:24:30.964870'),(10,'auth','0008_alter_user_username_max_length','2019-05-17 12:24:31.022083'),(11,'authentication','0001_initial','2019-05-17 12:24:37.464750'),(12,'admin','0001_initial','2019-05-17 12:24:40.246449'),(13,'admin','0002_logentry_remove_auto_add','2019-05-17 12:24:40.398480'),(14,'authtoken','0001_initial','2019-05-17 12:24:42.097311'),(15,'authtoken','0002_auto_20160226_1747','2019-05-17 12:24:43.166254'),(16,'authentication','0002_token','2019-05-17 12:24:43.209880'),(17,'authentication','0003_organization','2019-05-17 12:24:45.158097'),(18,'applications','0001_initial','2019-05-17 12:24:46.056859'),(19,'applications','0002_application_organization','2019-05-17 12:24:47.417285'),(20,'audit_trails','0001_initial','2019-05-17 12:24:48.943457'),(21,'auth','0004_group_organization','2019-05-17 12:24:51.092156'),(22,'authentication','0005_sip_server','2019-05-17 12:24:53.393477'),(23,'authentication','0006_user_preferences','2019-05-17 12:24:54.279816'),(24,'authentication','0007_auto_20171219_0554','2019-05-17 12:24:57.448031'),(25,'authentication','0008_auto_20180129_0331','2019-05-17 12:24:57.507356'),(26,'authentication','0009_auto_20180612_0226','2019-05-17 12:24:58.846037'),(27,'authentication','0010_auto_20180613_0657','2019-05-17 12:25:00.940830'),(28,'authentication','0011_auto_20180618_0622','2019-05-17 12:25:01.831159'),(29,'authentication','0012_auto_20180619_0529','2019-05-17 12:25:01.981605'),(30,'authentication','0013_user_type','2019-05-17 12:25:02.918086'),(31,'authentication','0014_auto_20190211_0105','2019-05-17 12:25:03.133591'),(32,'authentication','0015_auto_20190211_0213','2019-05-17 12:25:07.253902'),(33,'authentication','0016_auto_20190212_0610','2019-05-17 12:25:07.746037'),(34,'authentication','0017_auto_20190213_0640','2019-05-17 12:25:09.922668'),(35,'authentication','0018_auto_20190301_0522','2019-05-17 12:25:12.324255'),(36,'multimedia','0001_initial','2019-05-17 12:25:15.016697'),(37,'gateways','0001_initial','2019-05-17 12:25:28.489986'),(38,'gateways','0002_gateway_organization','2019-05-17 12:25:30.463948'),(39,'gateways','0003_sip_server','2019-05-17 12:25:33.516661'),(40,'gateways','0004_gatewayreturn_order','2019-05-17 12:25:40.775213'),(41,'gateways','0005_call_permission','2019-05-17 12:25:40.851088'),(42,'gateways','0006_auth_key_and_sync_multimedia','2019-05-17 12:25:42.622412');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_call`
--

DROP TABLE IF EXISTS `gateways_call`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_call` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(1) NOT NULL,
  `type` varchar(1) NOT NULL,
  `remote_address` varchar(255) NOT NULL,
  `start_time` datetime(6) NOT NULL,
  `end_time` datetime(6) NOT NULL,
  `gateway_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gateways_call_gateway_id_e671253a_fk_gateways_gateway_id` (`gateway_id`),
  CONSTRAINT `gateways_call_gateway_id_e671253a_fk_gateways_gateway_id` FOREIGN KEY (`gateway_id`) REFERENCES `gateways_gateway` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_call`
--

LOCK TABLES `gateways_call` WRITE;
/*!40000 ALTER TABLE `gateways_call` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_call` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_connection`
--

DROP TABLE IF EXISTS `gateways_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_connection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime(6) NOT NULL,
  `ip_address` char(39) NOT NULL,
  `reason` varchar(1) NOT NULL,
  `gateway_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gateways_connection_gateway_id_a07281f1_fk_gateways_gateway_id` (`gateway_id`),
  CONSTRAINT `gateways_connection_gateway_id_a07281f1_fk_gateways_gateway_id` FOREIGN KEY (`gateway_id`) REFERENCES `gateways_gateway` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_connection`
--

LOCK TABLES `gateways_connection` WRITE;
/*!40000 ALTER TABLE `gateways_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_gateway`
--

DROP TABLE IF EXISTS `gateways_gateway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_gateway` (
  `id` bigint(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `register_date` datetime(6) NOT NULL,
  `auto_registered` tinyint(1) NOT NULL,
  `version` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `android_build` varchar(255) NOT NULL,
  `android_version` varchar(255) NOT NULL,
  `imei` varchar(255) NOT NULL,
  `sim` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `auto_update` tinyint(1) NOT NULL,
  `force_update` tinyint(1) NOT NULL,
  `amc_expire_date` date DEFAULT NULL,
  `last_connect_time` datetime(6) DEFAULT NULL,
  `last_connect_ip` char(39) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `sync_sip` tinyint(1) NOT NULL,
  `sip_server_id` int(11) DEFAULT NULL,
  `auth_key` varchar(32) NOT NULL,
  `sync_multimedia` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gateways_gateway_server_id_15feeca9_fk_gateways_server_id` (`server_id`),
  KEY `gateways_gateway_organization_id_114b76df_fk_authentic` (`organization_id`),
  KEY `gateways_gateway_sip_server_id_69616600_fk_gateways_sipserver_id` (`sip_server_id`),
  CONSTRAINT `gateways_gateway_organization_id_114b76df_fk_authentic` FOREIGN KEY (`organization_id`) REFERENCES `authentication_organization` (`id`),
  CONSTRAINT `gateways_gateway_server_id_15feeca9_fk_gateways_server_id` FOREIGN KEY (`server_id`) REFERENCES `gateways_server` (`id`),
  CONSTRAINT `gateways_gateway_sip_server_id_69616600_fk_gateways_sipserver_id` FOREIGN KEY (`sip_server_id`) REFERENCES `gateways_sipserver` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_gateway`
--

LOCK TABLES `gateways_gateway` WRITE;
/*!40000 ALTER TABLE `gateways_gateway` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_gateway` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_gateway_applications`
--

DROP TABLE IF EXISTS `gateways_gateway_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_gateway_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_id` bigint(20) NOT NULL,
  `application_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gateways_gateway_applica_gateway_id_application_i_6fe0e757_uniq` (`gateway_id`,`application_id`),
  KEY `gateways_gateway_app_application_id_bd13e1d6_fk_applicati` (`application_id`),
  CONSTRAINT `gateways_gateway_app_application_id_bd13e1d6_fk_applicati` FOREIGN KEY (`application_id`) REFERENCES `applications_application` (`id`),
  CONSTRAINT `gateways_gateway_app_gateway_id_c59ddec7_fk_gateways_` FOREIGN KEY (`gateway_id`) REFERENCES `gateways_gateway` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_gateway_applications`
--

LOCK TABLES `gateways_gateway_applications` WRITE;
/*!40000 ALTER TABLE `gateways_gateway_applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_gateway_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_gatewayreturn`
--

DROP TABLE IF EXISTS `gateways_gatewayreturn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_gatewayreturn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rma_code` varchar(255) DEFAULT NULL,
  `reason` varchar(1) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `gateway_id` bigint(20) DEFAULT NULL,
  `replacement_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gateways_gatewayretu_gateway_id_3b14ccbf_fk_gateways_` (`gateway_id`),
  KEY `gateways_gatewayretu_replacement_id_e6b02f68_fk_gateways_` (`replacement_id`),
  CONSTRAINT `gateways_gatewayretu_gateway_id_3b14ccbf_fk_gateways_` FOREIGN KEY (`gateway_id`) REFERENCES `gateways_gateway` (`id`),
  CONSTRAINT `gateways_gatewayretu_replacement_id_e6b02f68_fk_gateways_` FOREIGN KEY (`replacement_id`) REFERENCES `gateways_gateway` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_gatewayreturn`
--

LOCK TABLES `gateways_gatewayreturn` WRITE;
/*!40000 ALTER TABLE `gateways_gatewayreturn` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_gatewayreturn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_order`
--

DROP TABLE IF EXISTS `gateways_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `order_date` date NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gateways_order_organization_id_a3444d9f_fk_authentic` (`organization_id`),
  CONSTRAINT `gateways_order_organization_id_a3444d9f_fk_authentic` FOREIGN KEY (`organization_id`) REFERENCES `authentication_organization` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_order`
--

LOCK TABLES `gateways_order` WRITE;
/*!40000 ALTER TABLE `gateways_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_order_gateways`
--

DROP TABLE IF EXISTS `gateways_order_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_order_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `gateway_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gateways_order_gateways_order_id_gateway_id_4bea5ce3_uniq` (`order_id`,`gateway_id`),
  KEY `gateways_order_gatew_gateway_id_f4a62f3f_fk_gateways_` (`gateway_id`),
  CONSTRAINT `gateways_order_gatew_gateway_id_f4a62f3f_fk_gateways_` FOREIGN KEY (`gateway_id`) REFERENCES `gateways_gateway` (`id`),
  CONSTRAINT `gateways_order_gateways_order_id_eef47e0f_fk_gateways_order_id` FOREIGN KEY (`order_id`) REFERENCES `gateways_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_order_gateways`
--

LOCK TABLES `gateways_order_gateways` WRITE;
/*!40000 ALTER TABLE `gateways_order_gateways` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_order_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_server`
--

DROP TABLE IF EXISTS `gateways_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_server`
--

LOCK TABLES `gateways_server` WRITE;
/*!40000 ALTER TABLE `gateways_server` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_sipserver`
--

DROP TABLE IF EXISTS `gateways_sipserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_sipserver` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `server` varchar(255) NOT NULL,
  `port` int(11) NOT NULL,
  `transport` varchar(1) NOT NULL,
  `srtp_mode` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_sipserver`
--

LOCK TABLES `gateways_sipserver` WRITE;
/*!40000 ALTER TABLE `gateways_sipserver` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_sipserver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_softwareupdate`
--

DROP TABLE IF EXISTS `gateways_softwareupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_softwareupdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_softwareupdate`
--

LOCK TABLES `gateways_softwareupdate` WRITE;
/*!40000 ALTER TABLE `gateways_softwareupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_softwareupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateways_softwareupdatelog`
--

DROP TABLE IF EXISTS `gateways_softwareupdatelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateways_softwareupdatelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `start_time` datetime(6) NOT NULL,
  `stop_time` datetime(6) NOT NULL,
  `error_code` int(11) NOT NULL,
  `message` longtext NOT NULL,
  `gateway_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gateways_softwareupd_gateway_id_7ec040a5_fk_gateways_` (`gateway_id`),
  CONSTRAINT `gateways_softwareupd_gateway_id_7ec040a5_fk_gateways_` FOREIGN KEY (`gateway_id`) REFERENCES `gateways_gateway` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateways_softwareupdatelog`
--

LOCK TABLES `gateways_softwareupdatelog` WRITE;
/*!40000 ALTER TABLE `gateways_softwareupdatelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `gateways_softwareupdatelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_appointment`
--

DROP TABLE IF EXISTS `medical_appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` datetime(6) NOT NULL,
  `end_time` datetime(6) NOT NULL,
  `status` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_appointment`
--

LOCK TABLES `medical_appointment` WRITE;
/*!40000 ALTER TABLE `medical_appointment` DISABLE KEYS */;
/*!40000 ALTER TABLE `medical_appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_availabilityslot`
--

DROP TABLE IF EXISTS `medical_availabilityslot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_availabilityslot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` datetime(6) NOT NULL,
  `end_time` datetime(6) NOT NULL,
  `interval` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_availabilityslot`
--

LOCK TABLES `medical_availabilityslot` WRITE;
/*!40000 ALTER TABLE `medical_availabilityslot` DISABLE KEYS */;
/*!40000 ALTER TABLE `medical_availabilityslot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_bloodglucose`
--

DROP TABLE IF EXISTS `medical_bloodglucose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_bloodglucose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blood_glucose` double NOT NULL,
  `time` datetime(6) NOT NULL,
  `is_manual` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_bloodglucose`
--

LOCK TABLES `medical_bloodglucose` WRITE;
/*!40000 ALTER TABLE `medical_bloodglucose` DISABLE KEYS */;
/*!40000 ALTER TABLE `medical_bloodglucose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_bloodpressure`
--

DROP TABLE IF EXISTS `medical_bloodpressure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_bloodpressure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `systolic` int(11) NOT NULL,
  `diastolic` int(11) NOT NULL,
  `pulse` int(11) NOT NULL,
  `time` datetime(6) NOT NULL,
  `is_manual` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_bloodpressure`
--

LOCK TABLES `medical_bloodpressure` WRITE;
/*!40000 ALTER TABLE `medical_bloodpressure` DISABLE KEYS */;
/*!40000 ALTER TABLE `medical_bloodpressure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_bodyparameter`
--

DROP TABLE IF EXISTS `medical_bodyparameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_bodyparameter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `codename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_bodyparameter`
--

LOCK TABLES `medical_bodyparameter` WRITE;
/*!40000 ALTER TABLE `medical_bodyparameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `medical_bodyparameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multimedia_clip`
--

DROP TABLE IF EXISTS `multimedia_clip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multimedia_clip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `file` varchar(255) NOT NULL,
  `md5` varchar(32) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `multimedia_clip_organization_id_a85bb7e1_fk_authentic` (`organization_id`),
  CONSTRAINT `multimedia_clip_organization_id_a85bb7e1_fk_authentic` FOREIGN KEY (`organization_id`) REFERENCES `authentication_organization` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multimedia_clip`
--

LOCK TABLES `multimedia_clip` WRITE;
/*!40000 ALTER TABLE `multimedia_clip` DISABLE KEYS */;
/*!40000 ALTER TABLE `multimedia_clip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multimedia_multimediaclip`
--

DROP TABLE IF EXISTS `multimedia_multimediaclip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multimedia_multimediaclip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  `url` varchar(200) NOT NULL,
  `is_global` tinyint(1) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `multimedia_multimedi_organization_id_b2bce140_fk_authentic` (`organization_id`),
  CONSTRAINT `multimedia_multimedi_organization_id_b2bce140_fk_authentic` FOREIGN KEY (`organization_id`) REFERENCES `authentication_organization` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multimedia_multimediaclip`
--

LOCK TABLES `multimedia_multimediaclip` WRITE;
/*!40000 ALTER TABLE `multimedia_multimediaclip` DISABLE KEYS */;
/*!40000 ALTER TABLE `multimedia_multimediaclip` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-17  6:53:51
